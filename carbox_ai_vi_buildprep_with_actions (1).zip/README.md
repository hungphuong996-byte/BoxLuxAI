CarBox AI Demo (Vietnamese Voice + OTA)
=======================================
This project is an extended Android launcher-like app (CarBox) with:
 - Offline Vietnamese voice commands using Vosk (requires external model)
 - OTA update checker (fetches version JSON and prompts to download APK)
 - Basic launcher UI (Navigation / YouTube / Voice)

IMPORTANT:
 - Vosk models are large (~15-200 MB). This demo does NOT include the model file.
 - Download a Vietnamese Vosk model (for example: vosk-model-small-vi-0.4) and place it on the device
   at /sdcard/vosk-model-small-vi (or change the path in VoskVoiceService.kt).
 - Add the Vosk dependency in Gradle and internet/record permissions.
 - Use Android Studio to import and build the project.

Steps to run:
 1. Import project into Android Studio.
 2. Add Vosk dependency if needed (already in app/build.gradle in this archive).
 3. Place the model folder on the device storage as above.
 4. Run app on physical device (microphone required).
