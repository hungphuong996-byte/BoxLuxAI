Continuous Build Instructions (GitHub Actions)
=============================================

This project includes a GitHub Actions workflow that will build a release APK automatically
when you push the repository to GitHub (branch 'main' or 'master'), or when you trigger the workflow manually.

Steps to produce an APK without a local PC:
1. Create a GitHub account if you don't have one (https://github.com).
2. Create a new repository (name it e.g. CarBoxAI).
3. Upload the entire project contents to the repo. You can use the GitHub Mobile app or the web UI:
   - On your phone, open github.com -> New repo -> Add files -> Upload files -> select the files from the ZIP you downloaded.
4. Commit to the 'main' branch.
5. Go to the 'Actions' tab in the repo. You'll see the 'Build CarBox APK' workflow running, or you can trigger it manually using 'Run workflow'.
6. When the workflow completes, go to the workflow run, and download the 'CarBox-release-apk' artifact (the generated APK).
7. Transfer the APK to your phone (it may already be accessible via mobile browser), then install it:
   - If Android blocks unknown sources, allow the installer temporarily for your file manager or browser.

Notes about signing:
- The generated APK by default will be unsigned (or signed with a debug key depending on Gradle config).
- For distribution, you should sign with your own keystore. If you need, follow these steps:
  a) Generate a keystore on a PC using keytool:
     keytool -genkey -v -keystore release.keystore -alias carbox -keyalg RSA -keysize 2048 -validity 10000
  b) Add the keystore to the repo (NOT recommended) or configure GitHub Secrets and modify the workflow to import the keystore.
  c) Update app/build.gradle signingConfigs to use the keystore.

Fast option:
- If you don't want to handle signing, you can ask a friendly shop or tech person to download the artifact and sign it for you.

If you want, I can:
- Prepare a ready-to-upload repository ZIP (this file) that already contains the Action workflow (this ZIP).
- Or I can prepare an alternate workflow that also signs the APK using keystore stored in GitHub Secrets (I will explain how to set secrets).

Download the prepared ZIP and follow the GitHub instructions above.
