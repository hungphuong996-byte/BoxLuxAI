package com.example.carbox

import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppListAdapter(
    private val packages: List<String>,
    private val pm: PackageManager,
    private val onClick: (String)->Unit
) : RecyclerView.Adapter<AppListAdapter.VH>() {

    class VH(view: View): RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.app_icon)
        val label: TextView = view.findViewById(R.id.app_label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return VH(v)
    }

    override fun getItemCount(): Int = packages.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val pkg = packages[position]
        holder.label.text = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg,0)).toString() } catch (e:Exception){ pkg }
        holder.icon.setImageDrawable(pm.getApplicationIcon(pkg))
        holder.itemView.setOnClickListener { onClick(pkg) }
    }
}
