package com.example.carbox

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private var voiceService: VoskVoiceService? = null
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(this, "Microphone permission granted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Microphone permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btn_nav).setOnClickListener {
            openApp("com.google.android.apps.maps")
        }

        findViewById<Button>(R.id.btn_youtube).setOnClickListener {
            openApp("com.google.android.youtube")
        }

        findViewById<Button>(R.id.btn_voice).setOnClickListener {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            } else {
                if (voiceService == null) voiceService = VoskVoiceService(this) { cmd -> handleVoiceCommand(cmd) }
                voiceService?.startListening()
            }
        }

        val recycler = findViewById<RecyclerView>(R.id.recycler_apps)
        recycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recycler.adapter = AppListAdapter(getInstalledApps(), packageManager) { pkg ->
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            intent?.let { startActivity(it) }
        }

        // Check OTA updates on startup (demo URL placeholders)
        val ota = OTAUpdater(this)
        ota.checkForUpdates(currentVersion = 1, updateUrl = "https://example.com/carbox/version.json", apkDownloadUrl = "https://example.com/carbox/carbox_latest.apk")
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceService?.stop()
    }

    private fun handleVoiceCommand(cmd: String) {
        val c = cmd.lowercase()
        runOnUiThread {
            when {
                "youtube" in c || "you tube" in c || "mở youtube" in c -> openApp("com.google.android.youtube")
                "bản đồ" in c || "map" in c || "mở bản đồ" in c -> openApp("com.google.android.apps.maps")
                "vietmap" in c || "viet map" in c -> openApp("vn.vietmap.viamichelin")
                "phát nhạc" in c -> openApp("com.spotify.music")
                else -> {
                    Toast.makeText(this, "Lệnh không rõ: $cmd", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun openApp(pkg: String) {
        val pm = packageManager
        val navIntent = pm.getLaunchIntentForPackage(pkg)
        if (navIntent != null) startActivity(navIntent)
        else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")))
    }

    private fun getInstalledApps(): List<String> {
        val pm = packageManager
        val packs = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        return packs.filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { it.packageName }
    }
}
