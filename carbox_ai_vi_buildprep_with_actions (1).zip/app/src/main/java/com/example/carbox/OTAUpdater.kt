package com.example.carbox

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.URL

class OTAUpdater(private val context: Context) {

    fun checkForUpdates(currentVersion: Int, updateUrl: String, apkDownloadUrl: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val json = URL(updateUrl).readText()
                val obj = JSONObject(json)
                val latest = obj.getInt("versionCode")
                if (latest > currentVersion) {
                    CoroutineScope(Dispatchers.Main).launch {
                        AlertDialog.Builder(context)
                            .setTitle("Cập nhật CarBox")
                            .setMessage("Đã có phiên bản mới ${obj.getString("versionName")}, bạn có muốn cập nhật không?")
                            .setPositiveButton("Cập nhật") { _, _ ->
                                val intent = Intent(Intent.ACTION_VIEW)
                                intent.setDataAndType(Uri.parse(apkDownloadUrl), "application/vnd.android.package-archive")
                                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                context.startActivity(intent)
                            }
                            .setNegativeButton("Để sau", null)
                            .show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
