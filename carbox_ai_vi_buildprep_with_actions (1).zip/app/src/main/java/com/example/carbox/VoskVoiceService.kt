package com.example.carbox

import android.content.Context
import android.util.Log
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.Model
import java.io.File

/**
 * VoskVoiceService
 * - Expects a Vosk Vietnamese model unpacked on device storage (e.g. /sdcard/vosk-model-small-vi)
 * - Uses Vosk Android library to perform offline speech recognition.
 *
 * Note: The model is not bundled in this project due to large size.
 */
class VoskVoiceService(private val context: Context, private val onCommand: (String)->Unit) : RecognitionListener {

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var speechService: SpeechService? = null

    fun startListening() {
        try {
            if (model == null) {
                val modelPath = File("/sdcard/vosk-model-small-vi")
                if (!modelPath.exists()) {
                    Log.e("VoskVoiceService", "Model path not found: ${modelPath.absolutePath}")
                    return
                }
                model = Model(modelPath.absolutePath)
            }
            recognizer = if (recognizer == null) Recognizer(model, 16000.0f) else recognizer
            speechService = SpeechService(recognizer, 16000.0f)
            speechService?.startListening(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stop() {
        try {
            speechService?.stop()
            recognizer?.close()
            model?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onResult(hypothesis: String?) {
        hypothesis?.let {
            val rx = "\"text\"\s*:\s*\"([^\"]*)\"".toRegex()
            val m = rx.find(it)
            val text = m?.groups?.get(1)?.value ?: ""
            if (text.isNotBlank()) {
                onCommand(text)
            }
        }
    }

    override fun onPartialResult(hypothesis: String?) {
        // ignore partials
    }

    override fun onError(exception: Exception?) {
        exception?.printStackTrace()
    }

    override fun onTimeout() {}
}
